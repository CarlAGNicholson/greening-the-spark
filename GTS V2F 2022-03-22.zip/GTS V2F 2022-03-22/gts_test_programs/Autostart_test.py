# Auto start test program
print("Hello! You weren't expecting this, were you?")
